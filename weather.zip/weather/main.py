from pyowm import OWM
import eel

owm = OWM("aded3b64d4701b6b4b7d235f9aa07e19")

eel.init("web")


@eel.expose
def get_weather(place):
    mgr = owm.weather_manager()
    observation = mgr.weather_at_place(place)
    weather = observation.weather


    t = weather.temperature("celsius")
    t1 = t['temp']
    t2 = t['feels_like']
    t3 = t['temp_max']
    t4 = t['temp_min']

    wi = weather.wind()['speed']
    humi = weather.humidity
    pr = weather.pressure['press']

    return ("В городе " + str(place) + " температура " + str(t1) + " °C" + " \n " +
            "Максимальная температура " + str(t3) + " °C" + "\n" +
            "Минимальная температура " + str(t4) + " °C" + "\n" + 
            "Ощущается как " + str(t2) + " °C" + "\n" +
            "Скорость ветра " + str(wi) + " м/с" + "\n" +
            "Давление " + str(pr) + " мм.рт.ст" + "\n" +
            "Влажность " + str(humi) +" %")


eel.start("main.html", size=(900, 650))